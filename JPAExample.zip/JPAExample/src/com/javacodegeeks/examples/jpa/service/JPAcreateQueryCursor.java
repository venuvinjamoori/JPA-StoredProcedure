/**
 * 
 * JPA Program for Examples Java Code Geeks by Rivu Chakraborty 
 * 
 */
package com.javacodegeeks.examples.jpa.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.mail.Session;
import javax.persistence.*;

import org.eclipse.persistence.*;
import org.eclipse.persistence.internal.helper.DatabaseType;
import org.eclipse.persistence.internal.sessions.ArrayRecord;
import org.eclipse.persistence.jpa.JpaEntityManager;
import org.eclipse.persistence.platform.database.jdbc.JDBCTypes;
import org.eclipse.persistence.platform.database.oracle.plsql.OraclePLSQLTypes;
import org.eclipse.persistence.platform.database.oracle.plsql.PLSQLStoredProcedureCall;
import org.eclipse.persistence.platform.database.oracle.plsql.PLSQLrecord;
import org.eclipse.persistence.queries.DataReadQuery;
import org.eclipse.persistence.queries.ReadAllQuery;
import org.eclipse.persistence.queries.StoredProcedureCall;

import com.javacodegeeks.examples.jpa.entity.Student;
import com.sun.javafx.scene.traversal.Direction;

/**
 * @author Rivu
 *
 */
public class JPAcreateQueryCursor {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory( "RivuChk_JPA" );
		EntityManager entitymanager =  emfactory.createEntityManager();
		
		
		
		//initialising a StoredProcedureCall object
		StoredProcedureCall call = new StoredProcedureCall();
		//Setting The Procedure Name
		call.setProcedureName("studentAll");
		
		//Defining The Out Cursor Parameters
		call.useNamedCursorOutputAsResultSet("data");
		
		//Initialising a DataReadQuery
		DataReadQuery databaseQuery = new DataReadQuery();
		//Setting Call		
		databaseQuery.setCall(call);
		
		
		 //Initialising and Executing The Call and Getting the Result as List
		Query query = ((JpaEntityManager)entitymanager.getDelegate()).createQuery(databaseQuery);
		List students = query.getResultList();
		
		//Creating Iterator for the List
		Iterator i=students.iterator();
		
		//Iterating Through
		while(i.hasNext())
		{
			ArrayRecord ar=(ArrayRecord) i.next();
			System.out.println(ar.values());
		}
		
		
		
		
		
	}

}
