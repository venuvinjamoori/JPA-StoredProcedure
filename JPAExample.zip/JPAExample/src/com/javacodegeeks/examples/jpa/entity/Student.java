package com.javacodegeeks.examples.jpa.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.eclipse.persistence.annotations.*;
import org.eclipse.persistence.*;


@NamedStoredProcedureQuery(name="studentById", procedureName="studentById",  parameters={
		@StoredProcedureParameter(queryParameter="id", name="id", direction=Direction.IN,type=Integer.class),
		@StoredProcedureParameter(queryParameter="sname", name="sname", direction=Direction.OUT,type=String.class),
		@StoredProcedureParameter(queryParameter="addr", name="addr", direction=Direction.OUT,jdbcTypeName="ADDRESS_OB")
	})

@Entity
public class Student {
	 @Id
	 @GeneratedValue(strategy= GenerationType.AUTO)
	 private int sid;
	 private String fname;
	 private String lname;
	 private String dept;
	 private int year;
	 private String email;
	
	public Student() {
		// TODO Auto-generated constructor stub
	}
	
	
	public Student(int sid, String fname, String lname, String dept, int year,
			String email) {
		super();
		this.sid = sid;
		this.fname = fname;
		this.lname = lname;
		this.dept = dept;
		this.year = year;
		this.email = email;
	}



	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getDept() {
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}



	@Override
	public String toString() {
		return "Student [sid=" + sid + ", fname=" + fname + ", lname=" + lname
				+ ", dept=" + dept + ", year=" + year + ", email=" + email
				+ "]";
	}

	
	
	
}
